package com.example.scheduling;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {

    // Demo 3
    @GetMapping("/demo3")
    String demo3() {
        return "demo2.html";
    }

    // Demo 4
    @PostMapping("/send")
    String demo4(@RequestParam String message) {
        System.out.println(message);
        return "demo2.html";
    }

    // Demo 5
    @GetMapping("/demo5")
    String demo5(Model model) {
        model.addAttribute("message", "Hello! It's me!");
        return "demo5.html";
    }

    // Demo 6
    @GetMapping("/demo6")
    String demo6get(Model model) {
        Message message = new Message("Hello world!");
        model.addAttribute("message", message);
        return "demo6.html";
    }

    @PostMapping("/demo6")
    String demo6post(@ModelAttribute Message message) {
        System.out.println(message.getText());
        return "demo6.html";
    }
}
