package com.example.scheduling;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling // Example of @EnableXxx
public class SchedulingDemo {

    @Scheduled(fixedRate = 1000) // @Scheduled set to 1000 milliseconds
    public void myScheduledTask() {
        System.out.println("Every second!");
    }
}