package com.example.scheduling;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {

    // Demo 3
    @GetMapping("/demo3")
    String demo3() {
        return "demo2.html";
    }

    // Demo 4
    @PostMapping("/send")
    String demo4(@RequestParam String message) {
        System.out.println(message);
        return "demo2.html";
    }

    // Demo 5
    @GetMapping("/demo5")
    String demo5(Model model) {
        model.addAttribute("message", "Hello! It's me!");
        return "demo5.html";
    }

    // Demo 6
    @GetMapping("/demo6")
    String demo6get(Model model) {
        Message message = new Message("Hello world!");
        model.addAttribute("message", message);
        return "demo6.html";
    }

    @PostMapping("/demo6")
    String demo6post(@ModelAttribute Message message) {
        System.out.println(message.getText());
        return "demo6.html";
    }

    // Exercise 1
    @GetMapping("/ex1")
    String ex1get() {
        return "ex1.html";
    }

    @PostMapping("/ex1")
    String ex1post(@RequestParam String username, @RequestParam String password) {
        System.out.println("Username: " + username + ", Password: " + password);
        return "ex1.html";
    }

    // Exercise 2
    @GetMapping("/ex2")
    String ex2get(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "ex2.html";
    }

    @PostMapping("/ex2")
    String ex2post(@ModelAttribute User user) {
        System.out.println("Username: " + user.getUsername() + ", Password: " + user.getPassword());
        return "ex2.html";
    }

    // Exercise 3
    @GetMapping("/ex3")
    String ex3get(Model model) {
        Admin admin = new Admin();
        model.addAttribute("admin", admin);
        return "ex3.html";
    }

    @PostMapping("/ex3")
    String ex3post(@ModelAttribute Admin admin) {
        System.out.println("Username: " + admin.getUsername() +
                ", Password: " + admin.getPassword() +
                ", Is a manager: " + admin.isManager() +
                ", Role: " + admin.getRole() +
                ", Description: " + admin.getDescription());
        return "ex3.html";
    }


}
