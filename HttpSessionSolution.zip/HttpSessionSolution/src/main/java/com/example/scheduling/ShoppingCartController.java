package com.example.scheduling;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ShoppingCartController {

    @Autowired
    ShoppingCart shoppingCart;

    @GetMapping("/")
    String demo1get(Model model) {
        model.addAttribute("items", shoppingCart.getItems());
        return "items";
    }

    @PostMapping("/")
    String demo1post(Model model, @RequestParam String item) {
        shoppingCart.addItem(item);
        model.addAttribute("items", shoppingCart.getItems());
        return "items";
    }

}
