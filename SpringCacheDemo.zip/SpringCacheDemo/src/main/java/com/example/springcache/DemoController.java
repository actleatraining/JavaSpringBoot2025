package com.example.springcache;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @Autowired
    private SlowService slowService;

    @GetMapping("/") // With request params
    String demo() {
        System.out.println(slowService.getData("test")); // will take 2s (the first request)
        System.out.println(slowService.getData("test")); // will return instantly
        System.out.println(slowService.getData("test2")); // will take 2s (the first request)
        System.out.println(slowService.getData("test2")); // will return instantly
        System.out.println(slowService.getData("test")); // will return instantly
        return "look for printouts in the console!";
    }

    @GetMapping("/empty") // With request params
    String emptyCache() {
        slowService.emptyCache();
        return "cache is emptied";
    }
}
