package com.example.SpringBootIntroductionDemo;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDogControllerRestTemplateExample {
    @Autowired
    private RestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = "http://localhost:" + port + "/dog";
    }

    @Test
    @Order(1)
    void testGetAllDogs() {
        ResponseEntity<Dog[]> response = restTemplate.getForEntity(baseUrl, Dog[].class);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertTrue(response.getBody().length > 0);
    }

    @Test
    @Order(2)
    void testGetDogById() {
        ResponseEntity<Dog> response = restTemplate.getForEntity(baseUrl + "/1", Dog.class);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals("Pluto", response.getBody().getName());
    }

    @Test
    @Order(3)
    void testCreateDog() {
        Dog dog = new Dog("Buddy", 3);
        ResponseEntity<Dog> response = restTemplate.postForEntity(baseUrl, dog, Dog.class);
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
        Assertions.assertNotNull(response.getBody().getId());
    }

    @Test
    @Order(4)
    void testUpdateDog() {
        Dog updated = new Dog("Pluto", 91);

        HttpEntity<Dog> request = new HttpEntity<>(updated);
        ResponseEntity<Dog> response = restTemplate.exchange(baseUrl + "/1", HttpMethod.PUT, request, Dog.class);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(91, response.getBody().getAge());
    }

    @Test
    @Order(5)
    void testDeleteDog() {
        ResponseEntity<Void> response = restTemplate.exchange(baseUrl + "/1", HttpMethod.DELETE, null, Void.class);
        Assertions.assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());

        // Confirm deletion - Throws exception because of NOT FOUND
        ResponseEntity<Dog> check = restTemplate.exchange(baseUrl + "/1", HttpMethod.GET, null, Dog.class);
        Assertions.assertEquals(HttpStatus.NOT_FOUND, check.getStatusCode());
    }
}
