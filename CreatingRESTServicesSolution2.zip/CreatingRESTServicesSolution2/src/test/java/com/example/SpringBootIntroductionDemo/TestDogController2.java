package com.example.SpringBootIntroductionDemo;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestDogController2 {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private static Long dogId = 1L;

    @Test
    @Order(1)
    void testCreateDog() throws Exception {
        Dog dog = new Dog("Buddy", 3);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/dog")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dog)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Buddy"))
                .andReturn();

        // Extract ID for later tests
        String json = result.getResponse().getContentAsString();
        dogId = objectMapper.readValue(json, Dog.class).getId();
    }

    @Test
    @Order(2)
    void testGetAllDogs() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/dog"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(3));
    }

    @Test
    @Order(3)
    void testGetDogById() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/dog/{id}", dogId))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Buddy"));
    }

    @Test
    @Order(4)
    void testUpdateDog() throws Exception {
        Dog updated = new Dog("Buddy", 5);

        mockMvc.perform(MockMvcRequestBuilders.put("/dog/{id}", dogId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updated)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Buddy"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.age").value(5));
    }

    @Test
    @Order(5)
    void testDeleteDog() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.delete("/dog/{id}", dogId))
                .andExpect(MockMvcResultMatchers.status().isNoContent());

        // Confirm deletion
        mockMvc.perform(MockMvcRequestBuilders.get("/dog/{id}", dogId))
                .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
}
