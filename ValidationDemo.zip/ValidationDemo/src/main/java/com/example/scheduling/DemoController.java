package com.example.scheduling;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DemoController {

    // Demo 1
    @GetMapping("/demo1")
    String demo1get(Model model) {
        Message message = new Message();
        model.addAttribute("message", message);
        return "demo1";
    }

    @PostMapping("/demo1")
    String demo1post(@ModelAttribute Message message, BindingResult result) {
        if (message.getText().length() == 0) {
            result.rejectValue("text", "text.empty");
        }
        if (result.hasErrors()) {
            return "demo1";
        }
        return "result";
    }


    // Demo 2
    @GetMapping("/demo2")
    String demo6get(Model model) {
        Message message = new Message();
        model.addAttribute("message", message);
        return "demo2";
    }

    @PostMapping("/demo2")
    String demo6post(@Valid Message message, BindingResult result) {
        if (result.hasErrors()) {
            return "demo2";
        }
        System.out.println(message.getText());
        return "result";
    }
}
