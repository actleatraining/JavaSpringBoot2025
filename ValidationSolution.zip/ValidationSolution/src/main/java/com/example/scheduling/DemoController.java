package com.example.scheduling;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DemoController {

    // Exercise 2
    @GetMapping("/ex2")
    String ex2get(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "ex2";
    }

    @PostMapping("/ex2")
    String ex2post(@ModelAttribute User user, BindingResult result) {
        if (user.getUsername().length() < 3 || user.getUsername().length() > 12) {
            result.rejectValue("username", "username.size");
        }
        if (user.getPassword().length() == 0) {
            result.rejectValue("password", "password.empty");
        }
        if (result.hasErrors()) {
            return "ex2";
        }
        System.out.println("Username: " + user.getUsername() + ", Password: " + user.getPassword());
        return "result";
    }

    // Exercise 3
    @GetMapping("/ex3")
    String ex3get(Model model) {
        Admin admin = new Admin();
        model.addAttribute("admin", admin);
        return "ex3";
    }

    @PostMapping("/ex3")
    String ex3post(@Valid Admin admin, BindingResult result) {
        if (result.hasErrors()) {
            return "ex3";
        }
        System.out.println("Username: " + admin.getUsername() +
                ", Password: " + admin.getPassword() +
                ", Is a manager: " + admin.isManager() +
                ", Role: " + admin.getRole() +
                ", Description: " + admin.getDescription());
        return "result";
    }
}
