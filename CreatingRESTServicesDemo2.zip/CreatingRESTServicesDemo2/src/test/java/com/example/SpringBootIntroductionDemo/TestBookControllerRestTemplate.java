package com.example.SpringBootIntroductionDemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TestBookControllerRestTemplate {
    @Autowired
    private RestTemplate restTemplate;

    @LocalServerPort
    private int port;

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = "http://localhost:" + port + "/book";
    }

    @Test
    void testCreateGetUpdateDeleteBook() {

        // GET all
        ResponseEntity<Book[]> getAllResponse = restTemplate.getForEntity(baseUrl, Book[].class);
        Assertions.assertEquals(HttpStatus.OK, getAllResponse.getStatusCode());
        Assertions.assertTrue(getAllResponse.getBody().length >= 1);

        // GET by ID
        ResponseEntity<Book> getResponse = restTemplate.getForEntity(baseUrl + "/1", Book.class);
        Assertions.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assertions.assertEquals("The Iliad", getResponse.getBody().getTitle());

        // POST
        Book book = new Book(null, "New Book", "New Author", 10);
        ResponseEntity<Book> postResponse = restTemplate.postForEntity(baseUrl, book, Book.class);
        Assertions.assertEquals(HttpStatus.CREATED, postResponse.getStatusCode());
        Assertions.assertNotNull(postResponse.getBody());
        Assertions.assertEquals("New Book", postResponse.getBody().getTitle());

        /*
        // PUT (update)
        Book updated = new Book(3L, "Pippi Longstocking 2 with a vengence", "Astrid Lindgren", 10);
        HttpEntity<Book> putRequest = new HttpEntity<>(updated);
        ResponseEntity<Book> putResponse = restTemplate.exchange(baseUrl + "/3", HttpMethod.PUT, putRequest, Book.class);
        Assertions.assertEquals(HttpStatus.OK, putResponse.getStatusCode());
        Assertions.assertEquals("Pippi Longstocking 2 with a vengence", putResponse.getBody().getTitle());

        // DELETE
        ResponseEntity<Void> deleteResponse = restTemplate.exchange(baseUrl + "/1", HttpMethod.DELETE, null, Void.class);
        Assertions.assertEquals(HttpStatus.NO_CONTENT, deleteResponse.getStatusCode());

        // GET after DELETE
        ResponseEntity<Book> getAfterDelete = restTemplate.getForEntity(baseUrl + "/1", Book.class);
        Assertions.assertEquals(HttpStatus.NOT_FOUND, getAfterDelete.getStatusCode());
         */
    }
}
