package com.example.SpringBootIntroductionDemo;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class SpringBootIntroductionDemoApplicationTests {

	@Autowired
	MockMvc mvc;

	@Autowired
	ObjectMapper mapper; // used to write a Java object to JSON for PUT and POST requests

	@Test
	@Order(1)
	public void testGetBooks() throws Exception {
		mvc.perform(
						MockMvcRequestBuilders.get("/book")
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(containsString("The Iliad")))
				.andExpect(MockMvcResultMatchers.content().string(containsString("The Hitchhikers Guide to the Galaxy")))
				.andExpect(MockMvcResultMatchers.content().string(containsString("Pippi Longstocking")));
	}

	@Test
	@Order(2)
	public void testGetBookById() throws Exception {
		mvc.perform(
						MockMvcRequestBuilders.get("/book/1")
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(containsString("The Iliad")));
	}

	@Test
	@Order(3)
	public void testPostBook() throws Exception {
		mvc.perform(
						MockMvcRequestBuilders.get("/book")
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(not(containsString("New Book"))));

		mvc.perform(
						MockMvcRequestBuilders.post("/book")
								.content(mapper.writeValueAsString(new Book(null, "New Book", "New Author", 10)))
								.contentType(MediaType.APPLICATION_JSON_UTF8)
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(containsString("New Book")));

		mvc.perform(
						MockMvcRequestBuilders.get("/book")
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(containsString("New Book")));
	}
}
