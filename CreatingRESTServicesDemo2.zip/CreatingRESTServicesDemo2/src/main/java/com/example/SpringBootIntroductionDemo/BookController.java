package com.example.SpringBootIntroductionDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
public class BookController {

    @Autowired
    BookRepository repository;

    @GetMapping("/book")
    public ResponseEntity<List<Book>> books() {
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body((List)repository.findAll());
    }

    @GetMapping("/book/{id}")
    public ResponseEntity<Book> book(@PathVariable Long id) {
        //return repository.findById(id).orElse(null);
        Optional<Book> book = repository.findById(id);
        if (book.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(book.get()); // 200 OK with body and content type
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .contentType(MediaType.APPLICATION_JSON)
                    .build(); // 404 with no body and content type
        }
    }

    @PostMapping("/book")
    public ResponseEntity<Book> post(@RequestBody Book book) {
        // return repository.save(book);
        Book savedBook = repository.save(book);
        return ResponseEntity.status(HttpStatus.CREATED)
                .contentType(MediaType.APPLICATION_JSON)
                .body(savedBook); // 201 and content type
    }
}
