package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DogRepository {
    private List<Dog> dogs;
    
    public DogRepository() {
        dogs = new ArrayList<>();

        for (int i = 1; i <= 9; i++) {
            dogs.add(new Dog(200L+i, "Dog " + i, 4 + i));
        }
    }

    // get one dog
    public Dog getDog(Long id) {
        for (Dog dog : dogs) {
            if (dog.getId().equals(id)) {
                return dog;
            }
        }
        return null;
    }

    // get all dogs
    public List<Dog> getDogs() {
        return dogs;
    }

    // add a dog
    public Dog addDog(Dog dog) {
        Dog lastDog = dogs.get(dogs.size()-1);
        dog.setId(lastDog.getId()+1); // set an id on the new dog, should be unique, will be done by the database in future exercises
        dogs.add(dog);
        return dog;
    }

    // edit a dog
    public Dog editDog(Dog dog) {
        Dog dogToEdit = this.getDog(dog.getId());
        if (dogToEdit != null) {
            dogToEdit.setName(dog.getName());
            dogToEdit.setAge(dog.getAge());
        }
        return dog;
    }

    // delete a dog
    public void deleteDog(Long id) {
        Dog dogToDelete = this.getDog(id);
        if (dogToDelete != null) {
            dogs.remove(dogToDelete);
        }
    }
}
