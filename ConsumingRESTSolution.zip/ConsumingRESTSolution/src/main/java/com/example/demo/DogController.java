package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Controller
public class DogController {

    private static final int PAGE_SIZE = 10;

    @Autowired
    private DogRepository dogRepository;

    @GetMapping("/")
    public String dogs(Model model, RestTemplate restTemplate) {
        //List<Dog> dogs = dogRepository.getDogs(); // todo replace with call GET /dog
        List<Dog> dogs = restTemplate.getForObject("http://localhost:8080/dog", ArrayList.class);
        model.addAttribute("dogs", dogs);
        return "dogs";
    }

    @GetMapping("/dog/{id}")
    public String dog(Model model, @PathVariable Long id, RestTemplate restTemplate) {
        //Dog dog = dogRepository.getDog(id); // todo replace with call GET /dog/{id}
        Dog dog = restTemplate.getForObject("http://localhost:8080/dog/" + id, Dog.class);
        model.addAttribute("dog", dog);

        return "dog";
    }

    @GetMapping("/add")
    public String add(Model model) {
        model.addAttribute("dog", new Dog());
        return "form";
    }

    @PostMapping("/save")
    public String set(@ModelAttribute Dog dog, RestTemplate restTemplate) {
        if (dog.isNew()) {
            //dogRepository.addDog(dog); // todo replace with call POST /dog (with dog object as json in request body)
            restTemplate.postForObject("http://localhost:8080/dog", dog, Dog.class);
        }
        else {
            dogRepository.editDog(dog); // todo replace with call PUT /dog/{id} (with dog object as json in request body
            restTemplate.put("http://localhost:8080/dog/" + dog.getId(), dog, Dog.class);
        }
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id, RestTemplate restTemplate) {
        //Dog dog = dogRepository.getDog(id); // todo replace with call GET /dog/{id}
        Dog dog = restTemplate.getForObject("http://localhost:8080/dog/" + id, Dog.class);
        model.addAttribute(dog);
        return "form";
    }
}
