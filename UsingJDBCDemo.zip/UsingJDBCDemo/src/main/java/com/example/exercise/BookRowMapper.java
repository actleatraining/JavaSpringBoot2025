package com.example.exercise;

import com.example.Book;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BookRowMapper implements RowMapper<Book> {
    @Override
    public Book mapRow(ResultSet rs, int rowNum) throws SQLException {

        Book book = new Book(rs.getLong("ID"),
                rs.getString("TITLE"),
                rs.getString("AUTHOR"),
                rs.getInt("PRICE"));


        return book;
    }
}


