package com.example.jdbc;

import com.example.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class JDBCBookRepository {

    @Autowired
    private DataSource dataSource;

    public int getBooksCount() {
        int bookCount = 0;
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS bookCount FROM book")) {

            if (rs.next()){
                bookCount = rs.getInt("bookCount");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookCount;
    }


    public List<Book> getBooks() {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, title, author, price FROM book")) {

            while (rs.next()){
                books.add(rsBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }


    public Book getBook(int id) {
        Book book = null;
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM book WHERE id = " + id)) {

            if (rs.next()){
                book = rsBook(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return book;
    }


    public List<Book> getBooksByAuthor(String author) {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, title, author, price FROM book WHERE author = '" + author + "'")) {

            while (rs.next()){
                books.add(rsBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    // Helper method to create a Book object instantiated with data from the ResultSet
    private Book rsBook(ResultSet rs) throws SQLException {
        return new Book(rs.getLong("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getInt("price"));
    }
}
