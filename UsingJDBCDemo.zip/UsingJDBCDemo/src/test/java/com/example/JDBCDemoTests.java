package com.example;

import com.example.jdbc.JDBCBookRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class JDBCDemoTests {

	@Autowired
	private JDBCBookRepository bookRepository;

	@Test
	public void testBooksCount() {
		int count = bookRepository.getBooksCount();
		Assertions.assertEquals(3, count);
	}


	@Test
	public void testGetBooks() {
		List<Book> books = bookRepository.getBooks();
		Assertions.assertEquals(3, books.size());
	}



	@Test
	public void testGetBookWithId() {
		Book book = bookRepository.getBook(2);
		Assertions.assertEquals("Douglas Adams", book.getAuthor());
	}



	@Test
	public void testGetBooksByAuthor() {
		List<Book> books = bookRepository.getBooksByAuthor("Homer");
		Assertions.assertEquals("The Iliad", books.get(0).getTitle());

		int count = bookRepository.getBooksCount();
		List<Book> books2 = bookRepository.getBooksByAuthor("Homer' or author not like 'Homer");
		Assertions.assertEquals(count, books2.size());
	}
}
