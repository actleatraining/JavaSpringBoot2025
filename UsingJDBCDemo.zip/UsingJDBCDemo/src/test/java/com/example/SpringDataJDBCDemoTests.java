package com.example;

import com.example.springjdbc.Dog;
import com.example.springjdbc.DogRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class SpringDataJDBCDemoTests {

	@Autowired
	DogRepository repository;

	@Test
	void contextLoads() {
	}

	@Test
	void count() {
		int count = repository.count();
		Assertions.assertEquals(2, count);
	}

	@Test
	void findAll() {
		List<Dog> dogs = repository.findAll();
		Assertions.assertEquals(2, dogs.size());
	}

	@Test
	void findById() {
		Dog dog = repository.findById(1L);
		Assertions.assertEquals("Pluto", dog.getName());
	}

	@Test
	void updateDog() {
		Dog dog = repository.findById(1L);

		int oldAge = dog.getAge();
		int newAge = oldAge+1;
		dog.setAge(newAge);
		repository.updateAge(dog);

		Dog olderDog = repository.findById(1L);
		Assertions.assertEquals(newAge, olderDog.getAge());
	}

	@Test
	void findByName() {
		List<Dog> dogs = repository.findByName("Fido");

		Assertions.assertEquals(1, dogs.size());
	}

	@Test
	void save() {
		int oldCount = repository.count();
		repository.save(new Dog("Chicco", 2));
		int newCount = repository.count();

		Assertions.assertEquals(oldCount+1, newCount);

	}
}
