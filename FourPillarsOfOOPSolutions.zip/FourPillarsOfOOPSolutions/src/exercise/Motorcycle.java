package exercise;

// Subclass 2 (Inheritance)
class Motorcycle extends Vehicle {
    private boolean hasSidecar;

    public Motorcycle(String brand, String model, double price, boolean hasSidecar) {
        super(brand, model, price);
        this.hasSidecar = hasSidecar;
    }

    @Override
    public double calculateRentalCost(int days) {
        double base = getRentalPricePerDay() * days;
        return hasSidecar ? base + 15 * days : base;
    }

    @Override
    public String getVehicleType() {
        return "Motorcycle";
    }

    public boolean hasSidecar() {
        return hasSidecar;
    }
}
