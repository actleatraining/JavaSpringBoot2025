package com.example.SpringBootIntroductionDemo;

import org.springframework.stereotype.Service;

@Service
public class Calculator {
    public int sum(int number1, int number2) {
        return number1 + number2;
    }
}
