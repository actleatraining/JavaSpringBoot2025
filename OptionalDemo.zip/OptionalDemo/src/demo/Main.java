package demo;

import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        Optional<String> name = Optional.of("Spring Boot");

        // Print if present
        name.ifPresent(System.out::println);

        // Provide default
        String result = name.orElse("Default");
        System.out.println(result);

        // Optional.empty
        Optional<String> empty = Optional.empty();
        System.out.println(empty.orElse("Fallback"));
    }
}
