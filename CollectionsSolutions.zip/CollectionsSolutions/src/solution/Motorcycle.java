package solution;

public class Motorcycle extends Vehicle {
    public Motorcycle(String licensePlate) {
        super(licensePlate);
    }

    public void drive() {
        System.out.println("Motorcycle is driving.");
    }
}
