package solution;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Garage {
    private List<Vehicle> vehicles = new ArrayList<>();
    private Map<String, Vehicle> vehicleMap = new HashMap<>();

    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
        vehicleMap.put(vehicle.getLicensePlate(), vehicle);
    }

    public <T> void printAll(List<T> list) {
        for (T item : list) {
            System.out.println(item);
        }
    }

    public Vehicle findByLicense(String plate) {
        return vehicleMap.get(plate);
    }

    public List<Vehicle> getVehiclesByType(Class<?> type) {
        List<Vehicle> result = new ArrayList<>();
        for (Vehicle v : vehicles) {
            if (type.isInstance(v)) {
                result.add(v);
            }
        }
        return result;
    }
}
