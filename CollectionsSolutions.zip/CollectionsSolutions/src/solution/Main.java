package solution;

public class Main {
    public static void main(String[] args) {
        Garage garage = new Garage();

        garage.addVehicle(new Car("ABC123"));
        garage.addVehicle(new Motorcycle("XYZ789"));
        garage.addVehicle(new Car("CAR456"));

        System.out.println("All Vehicles:");
        garage.printAll(garage.getVehiclesByType(Vehicle.class));

        System.out.println("\nFind by plate 'ABC123':");
        System.out.println(garage.findByLicense("ABC123"));

        System.out.println("\nOnly Cars:");
        garage.printAll(garage.getVehiclesByType(Car.class));

        System.out.println("\nOnly Motorcycles:");
        garage.printAll(garage.getVehiclesByType(Motorcycle.class));
    }
}
