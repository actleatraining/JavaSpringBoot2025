package com.example.SpringBootIntroductionDemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc // add this annotation
class SpringBootIntroductionDemoApplicationTests {

	@Autowired
	MockMvc mvc; // autowire a MockMvc object

	@Test
	void contextLoads() {
	}

	@Test
	public void testRequestParam() throws Exception {
		mvc.perform(
						MockMvcRequestBuilders.get("/ex1?number1=4&number2=7")
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(containsString("11")))
				.andExpect(MockMvcResultMatchers.content().string(not(containsString("7"))));
	}

	@Test
	public void testPathVariable() throws Exception {
		mvc.perform(
						MockMvcRequestBuilders.get("/ex1/8/9")
				)
				.andExpect(status().is2xxSuccessful())
				.andExpect(MockMvcResultMatchers.content().string(containsString("17")));
	}

}
