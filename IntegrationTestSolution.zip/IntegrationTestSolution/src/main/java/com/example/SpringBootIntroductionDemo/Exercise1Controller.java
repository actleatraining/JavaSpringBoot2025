package com.example.SpringBootIntroductionDemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Exercise1Controller {

    @GetMapping("/")
    String test() {
        return "Hello World!!!";
    }

    @GetMapping("/ex1")
    int hello(@RequestParam int number1, @RequestParam int number2) {
        return number1 + number2;
    }

    @GetMapping("/ex1/{number1}/{number2}")
    int hello4(@PathVariable int number1, @PathVariable int number2) { // Path variable
        return number1 + number2;
    }
}
