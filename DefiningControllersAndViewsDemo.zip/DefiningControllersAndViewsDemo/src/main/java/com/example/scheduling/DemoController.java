package com.example.scheduling;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class DemoController {

    // Demo 1
    @GetMapping("/demo1ex1")
    String demo1ex1() {
        return "view1.html";
    }

    @GetMapping("/demo1ex2")
    String demo1ex2(Model model) {
        model.addAttribute("message", "Hello World from a Model attribute!");
        return "view2.html";
    }

    @GetMapping("/demo1ex3")
    String demo1ex3(Model model) {
        model.addAttribute("user", new User("Hulk", "Smash"));
        return "view3.html";
    }

    // Demo 2
    @GetMapping("/demo2ex1")
    String demo3ex1(Model model) {
        model.addAttribute("numbers", List.of(5,2,7,5,4,8));
        return "view4.html";
    }

    @GetMapping("/demo2ex2")
    String demo3ex2(Model model) {
        model.addAttribute("numbers", List.of(5,2,7,5,4,8));
        return "view5.html";
    }

    // Demo 3
    @GetMapping("/demo3ex1")
    String demo2ex1(Model model) {
        model.addAttribute("user", new User("Hulk", "Smash"));
        model.addAttribute("user2", new User("Ironman", ""));
        return "view6.html";
    }

    @GetMapping("/demo3ex2")
    String demo2ex2(Model model) {
        model.addAttribute("number", 5);
        return "view7.html";
    }

    // Demo 4
    @GetMapping("/demo4ex1")
    String demo4ex1(Model model) {
        model.addAttribute("link", "demo3ex2");
        return "view8.html";
    }
}
