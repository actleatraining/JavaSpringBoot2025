package com.example.SpringBootIntroductionDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Exercise1Controller {

    // Exercise 1 - Autowired
    @Autowired
    Calculator calculator;

    Calculator calculator2;

    // Exercise 2 - Constructor parameter
    public Exercise1Controller(Calculator calculator) {
        this.calculator2 = calculator;
    }

    @GetMapping("/ex1") // With request params
    int hello(@RequestParam int number1, @RequestParam int number2) {
        return calculator.sum(number1, number2);
    }

    @GetMapping("/ex1/{number1}/{number2}") // With path variables
    int hello4(@PathVariable int number1, @PathVariable int number2) {
        return calculator2.sum(number1, number2);
    }
}
