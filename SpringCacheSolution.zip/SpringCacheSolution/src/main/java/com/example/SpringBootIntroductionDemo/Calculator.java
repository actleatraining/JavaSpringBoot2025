package com.example.SpringBootIntroductionDemo;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

@Service
@EnableCaching
@EnableScheduling
public class Calculator {

    @Cacheable("myCache")
    public int sum(int number1, int number2) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Running the method");
        return number1 + number2;
    }
}
