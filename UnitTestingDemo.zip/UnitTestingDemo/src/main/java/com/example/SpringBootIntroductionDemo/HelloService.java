package com.example.SpringBootIntroductionDemo;

import org.springframework.stereotype.Service;

@Service
public class HelloService {
    String hello(String name) {
        return "Hello " + name;
    }
}
