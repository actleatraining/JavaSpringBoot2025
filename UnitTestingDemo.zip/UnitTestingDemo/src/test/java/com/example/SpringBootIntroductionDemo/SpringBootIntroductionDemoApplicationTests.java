package com.example.SpringBootIntroductionDemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootIntroductionDemoApplicationTests {

	@Autowired
	HelloService helloService;

	@Test
	void contextLoads() {
	}

	@Test
	public void hello() {
		String result = helloService.hello("Pluto");
		Assertions.assertEquals("Hello Pluto", result);
	}
}
