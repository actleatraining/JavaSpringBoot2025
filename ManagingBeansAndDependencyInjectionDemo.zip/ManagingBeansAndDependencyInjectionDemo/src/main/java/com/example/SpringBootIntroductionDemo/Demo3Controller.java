package com.example.SpringBootIntroductionDemo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Demo3Controller {

    // Value Injection with property value as SpEL expression
    @Value("${my.calculation}")
    private String calculation;

    @GetMapping("/calculation")
    String calculationExample() {
        return "Hello (SpEL) " + calculation;
    }


    // Value Injection with annotation value as SpEL expression
    @Value("#{systemProperties['user.home']}")
    private String userHome;

    @GetMapping("/spel")
    String spelExample() {
        return "Hello (SpEL) " + userHome;
    }
}
