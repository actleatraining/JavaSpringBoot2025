package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Controller
public class DogController {

    private static final int PAGE_SIZE = 10;

    @Autowired
    private DogRepository dogRepository;

    RestClient restClient = RestClient.builder()
            .baseUrl("http://localhost:8080")
                .build();

    @GetMapping("/")
    public String dogs(Model model, RestTemplate restTemplate) {
        //List<Dog> dogs = dogRepository.getDogs(); // todo replace with call GET /dog
        List dogs = restClient.get()
                .uri("/dog")
                .retrieve()
                .body(ArrayList.class);

        model.addAttribute("dogs", dogs);
        return "dogs";
    }

    @GetMapping("/dog/{id}")
    public String dog(Model model, @PathVariable Long id) {
        //Dog dog = dogRepository.getDog(id); // todo replace with call GET /dog/{id}
        Dog dog = restClient.get()
                .uri("/dog/{id}", id)
                .retrieve()
                .body(Dog.class);

        model.addAttribute("dog", dog);

        return "dog";
    }

    @GetMapping("/add")
    public String add(Model model) {
        model.addAttribute("dog", new Dog());
        return "form";
    }

    @PostMapping("/save")
    public String set(@ModelAttribute Dog dog) {
        if (dog.isNew()) {
            //dogRepository.addDog(dog); // todo replace with call POST /dog (with dog object as json in request body)
            restClient.post()
                    .uri("/dog")
                    .body(dog)
                    .retrieve();
        }
        else {
            //dogRepository.editDog(dog); // todo replace with call PUT /dog/{id} (with dog object as json in request body
            restClient.put()
                    .uri("/dog/{id}", dog.getId())
                    .body(dog)
                    .retrieve();
        }
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String edit(Model model, @PathVariable Long id) {
        //Dog dog = dogRepository.getDog(id); // todo replace with call GET /dog/{id}
        Dog dog = restClient.get()
                .uri("/dog/{id}", id)
                .retrieve()
                .body(Dog.class);

        model.addAttribute(dog);
        return "form";
    }
}
