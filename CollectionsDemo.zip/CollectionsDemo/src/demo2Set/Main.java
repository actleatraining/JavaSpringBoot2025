package demo2Set;

import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Set<String> emails = new HashSet<>();
        emails.add("test@example.com");
        emails.add("test@example.com"); // Ignored

        System.out.println("Total emails: " + emails.size());
    }
}
