package com.example.scheduling;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoSessionScope {

    @Autowired
    Message message;

    // Demo 1
    @GetMapping("/")
    String demo1get(Model model, @RequestParam String text) {
        message.setText(text);
        model.addAttribute("message", message);
        return "demo1";
    }

    @GetMapping("/result")
    String demo6get(Model model) {
        model.addAttribute("message", message);
        return "demo1";
    }
}
