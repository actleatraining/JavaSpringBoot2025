package com.example.scheduling;

public class ManualMessage {
    String text;

    public ManualMessage() {
    }

    public ManualMessage(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
