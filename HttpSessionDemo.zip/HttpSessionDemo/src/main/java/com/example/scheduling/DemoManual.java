package com.example.scheduling;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class DemoManual {

    // Demo 1
    @GetMapping("/manual")
    String demo1get(Model model, @RequestParam String text, HttpSession session) {
        ManualMessage message = (ManualMessage)session.getAttribute("message");
        if (message==null) {
            message = new ManualMessage();
            session.setAttribute("message", message);
        }
        message.setText(text);
        model.addAttribute("message", message);
        return "demo1";
    }

    @GetMapping("/manualresult")
    String demo6get(Model model, HttpSession session) {
        ManualMessage message = (ManualMessage)session.getAttribute("message");
        model.addAttribute("message", message);
        return "demo1";
    }
}
