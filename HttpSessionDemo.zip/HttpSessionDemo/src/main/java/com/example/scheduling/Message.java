package com.example.scheduling;

import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

// todo uncomment the @SessionScope to put this object in session scope, otherwise it will be shared by every client
@Service
//@SessionScope
public class Message {
    String text;

    public Message() {
    }

    public Message(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
