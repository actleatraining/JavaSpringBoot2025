package com.example.SpringBootIntroductionDemo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootIntroductionDemoApplicationTests {

	@Autowired
	HelloService helloService;

	@Autowired
	FizzBuzzService fizzBuzz;

	@Test
	void contextLoads() {
	}

	@Test
	public void hello() {
		String result = helloService.hello("Pluto");
		Assertions.assertEquals("Hello Pluto", result);
	}

	@Test
	public void numberExpected() {
		Assertions.assertEquals("1", fizzBuzz.getValue(1));
		Assertions.assertEquals("2", fizzBuzz.getValue(2));
		Assertions.assertEquals("4", fizzBuzz.getValue(4));
	}

	@Test
	public void fizzExpected() {
		Assertions.assertEquals("fizz", fizzBuzz.getValue(3));
		Assertions.assertEquals("fizz", fizzBuzz.getValue(6));
		Assertions.assertEquals("fizz", fizzBuzz.getValue(9));
		Assertions.assertEquals("fizz", fizzBuzz.getValue(12));
	}

	@Test
	public void buzzExpected() {
		Assertions.assertEquals("buzz", fizzBuzz.getValue(5));
		Assertions.assertEquals("buzz", fizzBuzz.getValue(10));
		Assertions.assertEquals("buzz", fizzBuzz.getValue(20));
	}

	@Test
	public void fizzbuzzExpected() {
		Assertions.assertEquals("fizzbuzz", fizzBuzz.getValue(15));
		Assertions.assertEquals("fizzbuzz", fizzBuzz.getValue(30));
		Assertions.assertEquals("fizzbuzz", fizzBuzz.getValue(150));
	}


}
