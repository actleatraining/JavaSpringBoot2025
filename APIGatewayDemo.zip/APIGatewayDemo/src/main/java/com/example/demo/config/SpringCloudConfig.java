package com.example.demo.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringCloudConfig {

    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("BookService", r -> r
                        .path("/book/**")
                        .uri("http://localhost:8080/")) // start book api on port 8080 for this to work

                .route("DogService", r -> r
                        .path("/dog/**")
                        .filters(f -> f.addRequestHeader("X-Order-Service", "OrderHeader"))
                        .uri("http://localhost:8082/")) // start dog api on port 8082 for this to work

                .build();
    }
}