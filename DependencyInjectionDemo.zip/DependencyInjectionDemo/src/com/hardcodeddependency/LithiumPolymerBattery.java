package com.hardcodeddependency;

public class LithiumPolymerBattery implements Battery {
    public void charge() {
        System.out.println("Lithium Polymer Battery is charging...");
    }
}
