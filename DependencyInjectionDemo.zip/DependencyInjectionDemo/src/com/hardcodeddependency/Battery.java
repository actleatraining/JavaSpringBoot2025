package com.hardcodeddependency;

public interface Battery {
    void charge();
}
