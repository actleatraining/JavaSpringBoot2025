package com.hardcodeddependency;

public class Main {

    public static void main(String[] args) {

        // Can't controll the type of battery - it is hard-coded into the Phone class
        Phone phone = new Phone();

        phone.chargeBattery();
    }
}
