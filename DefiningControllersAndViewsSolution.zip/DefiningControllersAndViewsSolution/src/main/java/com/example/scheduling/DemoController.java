package com.example.scheduling;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class DemoController {

    @GetMapping("/ex1")
    String demo1ex1() {
        return "view1.html";
    }

    @GetMapping("/ex2")
    String demo1ex2(Model model) {
        model.addAttribute("dog", new Dog("Pluto", 3));
        return "view2.html";
    }

    @GetMapping("/ex3")
    String demo1ex3(Model model) {
        List<Dog> dogs = new ArrayList<>();
        dogs.add(new Dog("Pluto", 3));
        dogs.add(new Dog("Ludde", 13));
        dogs.add(new Dog("Chicco", 2));
        model.addAttribute("dogs", dogs);
        return "view3.html";
    }

    @GetMapping("/ex5")
    String demo1ex5(Model model, @RequestParam String name) {
        Map<String, Dog> dogMap = new HashMap<>();
        dogMap.put("Pluto", new Dog("Pluto", 3));
        dogMap.put("Ludde", new Dog("Ludde", 13));
        dogMap.put("Chicco", new Dog("Chicco", 2));

        Dog dog = dogMap.get(name);
        model.addAttribute("dog", dog);
        return "view2";
    }

    @GetMapping("/ex6")
    String demo1ex6(Model model) {
        List<Dog> dogs = new ArrayList<>();
        dogs.add(new Dog("Pluto", 3));
        dogs.add(new Dog("Ludde", 13));
        dogs.add(new Dog("Chicco", 2));
        model.addAttribute("dogs", dogs);
        return "view4.html";
    }
}
