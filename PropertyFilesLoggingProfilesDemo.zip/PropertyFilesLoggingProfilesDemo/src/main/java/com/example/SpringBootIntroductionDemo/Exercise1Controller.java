package com.example.SpringBootIntroductionDemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Exercise1Controller {

    Logger logger = LoggerFactory.getLogger(Exercise1Controller.class);

    @GetMapping("/")
    String test() {
        logger.info("Info!");
        logger.warn("Warning!");
        return "Hello World!!!";
    }

    @GetMapping("/ex2")
    String hello(@RequestParam String name) {
        logger.info("Running method hello");
        return "Hello " + name;
    }

    @GetMapping("/ex3")
    String hello3(@RequestParam(required=false, defaultValue = "Stranger") String name) {
        logger.info("Running method hello3");
        return "Hello " + name + "!";
    }

    @GetMapping("/ex4/{name}")
    String hello4(@PathVariable String name) {
        logger.info("Running method hello4");
        return "Hello " + name;
    }
}
