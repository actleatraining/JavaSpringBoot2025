package demo5;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<BankAccount> accounts = new ArrayList<>();
        accounts.add(new SavingsAccount("Anna", 1000, 0.05));
        accounts.add(new CheckingAccount("Bob", 1500));

        for (BankAccount acc : accounts) {
            acc.deposit(100);
            acc.endOfMonth(); // Calls overridden method based on actual object
            acc.printBalance();
        }
    }
}
