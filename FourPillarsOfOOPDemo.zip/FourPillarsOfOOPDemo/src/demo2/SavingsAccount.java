package demo2;

public class SavingsAccount extends BankAccount {
    private double interestRate;

    public SavingsAccount(String owner, double initialBalance, double interestRate) {
        super(owner, initialBalance); // Call superclass constructor
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        if (interestRate >= 0) {
            this.interestRate = interestRate;
        }
    }

    public void applyInterest() {
        double interest = getBalance() * interestRate;
        deposit(interest); // Reuse deposit() from superclass
    }
}

