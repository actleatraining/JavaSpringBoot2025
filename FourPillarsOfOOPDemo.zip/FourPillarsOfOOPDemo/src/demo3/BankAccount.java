package demo3;

public class BankAccount {
    protected String owner;
    protected double balance;

    public BankAccount(String owner, double balance) {
        this.owner = owner;
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println(owner + " deposited " + amount);
    }

    public void endOfMonth() {
        System.out.println("Bank Account");
    }

    public void printBalance() {
        System.out.println(owner + "'s balance: " + balance);
    }
}